package dev.acore;

import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * ACore - single file anticheat for Paper 1.21.x
 *
 * one file, no dependencies. everything runs off bukkit events, so no
 * packet library is needed to compile. packet only stuff (full timer,
 * blink) is approximated with event timing here.
 *
 * checks are grouped by what they catch. each one is independent, can be
 * turned off in config.yml, and feeds one shared violation system:
 *
 *   5 vl  -> alert to staff with acore.alerts
 *  10 vl  -> setback (rubber band to last safe spot)
 *  20 vl  -> 14 day ban, ban screen in game, embed to the discord webhook
 *
 * vl decay slowly over time so one lag spike never bans anyone.
 */
public final class ACore extends JavaPlugin implements Listener {

    // ------------------------------------------------------------------
    // constants we don't expose in config because changing them is how you
    // end up with a broken anticheat and a support channel full of appeals
    // ------------------------------------------------------------------

    private static final long BAN_MS = 14L * 24L * 60L * 60L * 1000L;
    private static final String APPEAL_URL = "https://discord.gg/invite";

    // no 0/O or 1/I in ban ids, people read them out loud in appeals
    private static final String BAN_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final Random RANDOM = new Random();

    private static ACore instance;

    private final Map<UUID, PlayerData> players = new HashMap<>();
    private final Map<String, CheckConfig> checks = new HashMap<>();
    private final Set<UUID> exempt = new HashSet<>();

    private String webhookUrl;
    private boolean alertsEnabled = true;
    private boolean debug = false;

    public static ACore get() { return instance; }

    // ==================================================================
    // lifecycle
    // ==================================================================

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        loadChecks();

        webhookUrl = getConfig().getString("webhook", "");
        alertsEnabled = getConfig().getBoolean("alerts", true);

        Bukkit.getPluginManager().registerEvents(this, this);
        for (Player p : Bukkit.getOnlinePlayers()) {
            players.put(p.getUniqueId(), new PlayerData(p));
        }
        // ping spoof needs keepalive samples, sample everyone once a second
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                PlayerData pd = players.get(p.getUniqueId());
                if (pd != null) {
                    pd.keepAliveSample();
                    run("PingSpoofA", pd, () -> Checks.PingSpoofA.check(pd));
                }
            }
        }, 20L, 20L);

        // hourly summary for ops, cheap and useful on lifesteal
        Bukkit.getScheduler().runTaskTimer(this, this::hourlySummary, 20L * 3600, 20L * 3600);
        getLogger().info("ACore loaded, " + checks.size() + " checks registered.");
    }

    @Override
    public void onDisable() {
        players.clear();
        instance = null;
    }

    /** reads config.yml and registers every check with its config values */
    private void loadChecks() {
        FileConfiguration c = getConfig();
        webhookUrl = c.getString("webhook", webhookUrl == null ? "" : webhookUrl);

        register("SpeedA", 20, true, "horizontal speed above vanilla with tolerance for ping and potions");
        register("SpeedB", 20, true, "air speed without sprint/jump boost, catches low speed cheats");
        register("VelocityA", 15, true, "blocks gained per second above what movement allows, catches fly and vsp");
        register("StepA", 15, true, "vertical step above 1.025 blocks per move");
        register("FlyA", 15, true, "hovering, falling slower than vanilla gravity allows");
        register("JesusA", 15, true, "walking on liquids without frost walker or a boat");
        register("NoSlowA", 15, true, "full sprint speed while eating, drinking or drawing a bow");
        register("SneakA", 10, true, "sneak speed above vanilla sneak multiplier");
        register("SprintA", 10, true, "sprinting while blind, hungry or floating in a vehicle");
        register("SpiderA", 15, true, "climbing a flat wall without a ladder or vine");
        register("HighJumpA", 15, true, "jump height above vanilla plus jump boost");
        register("ElytraA", 15, true, "gliding state without an elytra in the chest slot");
        register("LevitateA", 10, true, "rising without levitation, shulker ammo or elytra");

        register("KillAuraA", 20, true, "rotation snap between ticks while attacking");
        register("KillAuraB", 20, true, "attacks per second above vanilla cooldown handling");
        register("KillAuraC", 15, true, "hitting entities behind or inside the player head direction");
        register("ReachA", 20, true, "attack distance above 3.4 blocks");
        register("AutoClickerA", 15, true, "cps cap plus zero variance between clicks, macro signature");
        register("NoHitDelayA", 10, true, "arm swings above the 12 per second cap");
        register("CriticalsA", 15, true, "critical hits without falling");
        register("HitSelectA", 15, true, "damage cancelling in a pattern that matches hit selection");
        register("FastBowA", 15, true, "bow fully drawn in under 10 ticks");

        register("FastBreakA", 15, true, "breaking blocks faster than tool and efficiency allow");
        register("FastPlaceA", 10, true, "placing blocks faster than the vanilla 4 tick cooldown");
        register("NukerA", 20, true, "breaking many blocks per second across a wide area");
        register("GhostHandA", 15, true, "breaking through blocks with no line to the target");
        register("AutoToolA", 10, true, "hotbar slot changing the same tick a block starts breaking");
        register("FastLadderA", 10, true, "climbing faster than the vanilla ladder speed");
        register("ScaffoldA", 20, true, "sprint bridging without looking down, and bridge fly patterns");
        register("LiquidInteractA", 10, true, "placing blocks against liquids from impossible angles");

        register("XrayA", 0, true, "diamond mining pattern too efficient to be natural, manual review only");
        register("TimerA", 20, true, "event rate above the 20 ticks per second server rate");
        register("FastEatA", 10, true, "consuming items faster than the 32 tick eat time");
        register("InventoryMoveA", 15, true, "clicking inventory while moving at full sprint");
        register("FastChestA", 10, true, "inventory click rates above human clickers");
        register("NoRotationA", 10, true, "breaking or placing with a perfectly frozen camera");

        register("ChatSpamA", 10, true, "chat messages above the rate limit");
        register("AutoRespawnA", 10, true, "respawning instantly on a macro pattern");
        register("PingSpoofA", 15, true, "keepalive gap pattern that does not match real network latency");
        register("BadPacketsA", 15, true, "impossible input state combos, like sprinting while sneaking");
        register("SpeedC", 20, true, "average blocks per second above vanilla sprint over a full second");
        register("FlyB", 15, true, "fall profile that does not accelerate like vanilla gravity");
        register("VelocityB", 15, true, "ignoring server knockback");
        register("TimerB", 20, true, "move event rate above tick rate over a 4 second window");
        register("AimAssistA", 15, true, "rotation entropy too uniform during fights");
        register("KillAuraD", 15, true, "multi target attack rhythm");
        register("ReachB", 20, true, "average attack distance above reach over 30 hits");
        register("MacroA", 15, true, "constant click rate with no breathing");
        register("ScaffoldB", 15, true, "placing at high rate with a frozen camera");
        register("AutoTotemA", 15, true, "offhand totem swaps faster than humanly possible during fights");
        register("NoSlowB", 15, true, "average speed while using an item above the use slow cap");
        register("StepB", 15, true, "repeated oversized vertical steps");
        register("SpeedD", 20, true, "instant acceleration to full sprint in one tick");
        register("JesusB", 15, true, "sustained liquid top walking speed");
        register("FastBreakB", 15, true, "same block rebroken inside the vanilla cooldown");
        register("KillAuraE", 15, true, "attack intervals too regular to be human");
        register("TimerC", 20, true, "repeated tick rate bursts");
        register("CriticalsB", 15, true, "flat ground crits on a pattern");
        register("HitSelectB", 15, true, "sustained damage window sync");
        register("InvMoveB", 10, true, "sustained inventory clicking while moving");
    }

    private void register(String name, int maxVl, boolean enabled, String description) {
        String path = "checks." + name;
        CheckConfig cc = new CheckConfig(
                getConfig().getBoolean(path + ".enabled", enabled),
                getConfig().getInt(path + ".max-vl", maxVl > 0 ? maxVl : 20),
                getConfig().getString(path + ".description", description));
        checks.put(name, cc);
        if (!getConfig().contains(path + ".enabled")) {
            getConfig().set(path + ".enabled", enabled);
            getConfig().set(path + ".max-vl", cc.maxVl);
            getConfig().set(path + ".description", description);
        }
    }

    boolean enabled(String name) {
        CheckConfig cc = checks.get(name);
        return cc != null && cc.enabled;
    }

    int maxVl(String name) {
        CheckConfig cc = checks.get(name);
        return cc == null ? 20 : cc.maxVl;
    }

    private static final class CheckConfig {
        final boolean enabled;
        final int maxVl;
        final String description;
        CheckConfig(boolean enabled, int maxVl, String description) {
            this.enabled = enabled;
            this.maxVl = maxVl;
            this.description = description;
        }
    }

    // ==================================================================
    // commands
    // ==================================================================

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§8[§bACore§8] §7/acore alerts, status, exempt, violations, debug, reload");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "alerts" -> {
                alertsEnabled = !alertsEnabled;
                sender.sendMessage("§8[§bACore§8] §7alerts " + (alertsEnabled ? "§aon" : "§coff"));
            }
            case "debug" -> {
                debug = !debug;
                sender.sendMessage("§8[§bACore§8] §7verbose logs " + (debug ? "§aon" : "§coff"));
            }
            case "status" -> {
                sender.sendMessage("§8[§bACore§8] §7" + checks.size() + " checks, "
                        + players.size() + " players tracked");
                int flagged = 0;
                for (PlayerData pd : players.values()) flagged += pd.totalFlags > 0 ? 1 : 0;
                sender.sendMessage("§8[§bACore§8] §7players with flags: §b" + flagged);
            }
            case "exempt" -> {
                if (args.length < 2) {
                    sender.sendMessage("§8[§bACore§8] §7usage: /acore exempt <player>");
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) {
                    sender.sendMessage("§8[§bACore§8] §cplayer not found");
                    return true;
                }
                if (exempt.remove(t.getUniqueId())) {
                    sender.sendMessage("§8[§bACore§8] §7removed exemption for " + t.getName());
                } else {
                    exempt.add(t.getUniqueId());
                    sender.sendMessage("§8[§bACore§8] §7exempted " + t.getName());
                }
            }
            case "violations" -> {
                if (args.length < 2) {
                    sender.sendMessage("§8[§bACore§8] §7usage: /acore violations <player>");
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                if (t == null) {
                    sender.sendMessage("§8[§bACore§8] §cplayer not found");
                    return true;
                }
                PlayerData pd = players.get(t.getUniqueId());
                if (pd == null || pd.violations.isEmpty()) {
                    sender.sendMessage("§8[§bACore§8] §7" + t.getName() + " is clean");
                    return true;
                }
                sender.sendMessage("§8[§bACore§8] §f" + t.getName() + " §7violations:");
                pd.violations.entrySet().stream()
                        .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
                        .forEach(v -> sender.sendMessage("  §b" + v.getKey() + " §7vl §f"
                                + String.format(Locale.ROOT, "%.1f", v.getValue())));
                sender.sendMessage("  §7total flags since join: §f" + pd.totalFlags);
            }
            case "reload" -> {
                reloadConfig();
                loadChecks();
                sender.sendMessage("§8[§bACore§8] §aconfig reloaded");
            }
            default -> sender.sendMessage("§8[§bACore§8] §7unknown subcommand");
        }
        return true;
    }

    // ==================================================================
    // events
    // ==================================================================

    @EventHandler
    public void onJoin(org.bukkit.event.player.PlayerJoinEvent e) {
        PlayerData pd = new PlayerData(e.getPlayer());
        pd.rebuild(e.getPlayer());
        players.put(e.getPlayer().getUniqueId(), pd);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        players.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        PlayerData pd = data(p);
        if (pd == null) return;
        pd.rebuild(p);

        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getBlockX() == to.getBlockX()
                && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ()) {
            // rotation only packet. still useful for killaura checks
            pd.rotationTick(p, to.getYaw(), to.getPitch());
            run("NoRotationA", pd, () -> Checks.NoRotationA.check(pd));
            return;
        }

        Move move = new Move(from, to);
        pd.moveTick(p, move);

        if (pd.moving) {
            run("SpeedA", pd, () -> Checks.SpeedA.check(pd, move));
            run("SpeedB", pd, () -> Checks.SpeedB.check(pd, move));
            run("VelocityA", pd, () -> Checks.VelocityA.check(pd, p));
            run("StepA", pd, () -> Checks.StepA.check(pd, move));
            run("FlyA", pd, () -> Checks.FlyA.check(pd, move));
            run("JesusA", pd, () -> Checks.JesusA.check(pd, move));
            run("NoSlowA", pd, () -> Checks.NoSlowA.check(pd, move));
            run("SneakA", pd, () -> Checks.SneakA.check(pd, move));
            run("SpiderA", pd, () -> Checks.SpiderA.check(pd, move));
            run("HighJumpA", pd, () -> Checks.HighJumpA.check(pd, move));
            run("LevitateA", pd, () -> Checks.LevitateA.check(pd, move));
            run("FastLadderA", pd, () -> Checks.FastLadderA.check(pd, move));
            run("ScaffoldA", pd, () -> Checks.ScaffoldA.check(pd, p, move));
            run("ScaffoldB", pd, () -> Checks2.ScaffoldB.check(pd, move));
            run("TimerA", pd, () -> Checks.TimerA.check(pd));
            run("InventoryMoveA", pd, () -> Checks.InventoryMoveA.check(pd, move));
            run("FastBowA", pd, () -> Checks.FastBowA.check(pd));
            run("BadPacketsA", pd, () -> Checks.BadPacketsA.check(pd));
            run("SpeedC", pd, () -> Checks2.SpeedC.check(pd, move));
            run("FlyB", pd, () -> Checks2.FlyB.check(pd, move));
            run("VelocityB", pd, () -> Checks2.VelocityB.check(pd, move));
            run("TimerB", pd, () -> Checks2.TimerB.check(pd));
            run("NoSlowB", pd, () -> Checks2.NoSlowB.check(pd, move));
            run("StepB", pd, () -> Checks2.StepB.check(pd, move));
            run("SpeedD", pd, () -> Checks2.SpeedD.check(pd, move));
            run("JesusB", pd, () -> Checks2.JesusB.check(pd, move));
            run("TimerC", pd, () -> Checks2.TimerC.check(pd));
            run("HitSelectB", pd, () -> Checks2.HitSelectB.check(pd));
            run("InvMoveB", pd, () -> Checks2.InvMoveB.check(pd, move));
        }
        pd.rotationTick(p, to.getYaw(), to.getPitch());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        PlayerData pd = data(p);
        if (pd == null) return;
        pd.rebuild(p);
        pd.registerAttack();
        double dist = p.getLocation().distance(e.getEntity().getLocation());
        run("ReachA", pd, () -> Checks.ReachA.check(pd, dist));
        run("KillAuraA", pd, () -> Checks.KillAuraA.check(pd));
        run("KillAuraB", pd, () -> Checks.KillAuraB.check(pd));
        run("KillAuraC", pd, () -> Checks.KillAuraC.check(pd, p, e.getEntity()));
        run("CriticalsA", pd, () -> Checks.CriticalsA.check(pd, p, e.getCause()));
        run("CriticalsB", pd, () -> Checks2.CriticalsB.check(pd));
        run("KillAuraE", pd, () -> Checks2.KillAuraE.check(pd));
        run("HitSelectA", pd, () -> Checks.HitSelectA.check(pd, e.getEntity()));
        run("AutoClickerA", pd, () -> Checks.AutoClickerA.check(pd));
        run("AimAssistA", pd, () -> Checks2.AimAssistA.check(pd));
        run("KillAuraD", pd, () -> Checks2.KillAuraD.check(pd));
        run("ReachB", pd, () -> Checks2.ReachB.check(pd));
        run("MacroA", pd, () -> Checks2.MacroA.check(pd));
        run("AutoTotemA", pd, () -> Checks2.AutoTotemA.check(pd));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        if (e.getAction() == Action.LEFT_CLICK_AIR || e.getAction() == Action.LEFT_CLICK_BLOCK) {
            pd.registerSwing();
            run("NoHitDelayA", pd, () -> Checks.NoHitDelayA.check(pd));
        }
        if (e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            pd.registerPlace(e.getClickedBlock() == null ? null : e.getClickedBlock().getLocation(),
                    e.getClickedBlock() == null ? null : e.getClickedBlock().getRelative(e.getBlockFace()).getLocation());
            run("FastPlaceA", pd, () -> Checks.FastPlaceA.check(pd));
            run("LiquidInteractA", pd, () -> Checks.LiquidInteractA.check(pd, e.getPlayer()));
            run("ScaffoldA", pd, () -> Checks.ScaffoldA.interact(pd, e.getPlayer()));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        pd.rebuild(e.getPlayer());
        pd.registerBreak(e.getBlock().getType(), e.getBlock().getLocation());
        run("FastBreakA", pd, () -> Checks.FastBreakA.check(pd, e.getPlayer(), e.getBlock()));
        run("FastBreakB", pd, () -> Checks2.FastBreakB.check(pd, e.getBlock().getLocation()));
        run("NukerA", pd, () -> Checks.NukerA.check(pd));
        run("GhostHandA", pd, () -> Checks.GhostHandA.check(pd, e.getPlayer(), e.getBlock()));
        run("AutoToolA", pd, () -> Checks.AutoToolA.check(pd));
        run("XrayA", pd, () -> Checks.XrayA.check(pd, e.getPlayer(), e.getBlock()));
        run("NoRotationA", pd, () -> Checks.NoRotationA.check(pd));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockDamage(BlockDamageEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd != null) pd.blockDamageTick(e.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        pd.registerPlaceSelf(e.getBlock().getLocation());
        run("FastPlaceA", pd, () -> Checks.FastPlaceA.check(pd));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        pd.registerConsume();
        run("FastEatA", pd, () -> Checks.FastEatA.check(pd));
        run("NoSlowA", pd, () -> Checks.NoSlowA.consume(pd));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBow(FoodLevelChangeEvent e) {
        // drawing a bow drains hunger slower, we only use this to know the bow is out
        if (e.getEntity() instanceof Player p) {
            PlayerData pd = data(p);
            if (pd != null && p.getInventory().getItemInMainHand().getType() == Material.BOW) {
                pd.bowTicks = 10;
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onChat(AsyncPlayerChatEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        pd.registerChat();
        // chat checks run async safe, they only touch their own deques
        if (Checks.ChatSpamA.check(pd)) flag(pd, "ChatSpamA", 1);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSwing(PlayerAnimationEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        pd.registerSwing();
        run("NoHitDelayA", pd, () -> Checks.NoHitDelayA.check(pd));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        PlayerData pd = data(p);
        if (pd == null) return;
        pd.registerInvClick();
        if (e.getSlot() == 40) pd.registerOffhandSwap();
        run("FastChestA", pd, () -> Checks.FastChestA.check(pd));
        run("AutoTotemA", pd, () -> Checks2.AutoTotemA.check(pd));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onGlide(EntityToggleGlideEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        PlayerData pd = data(p);
        if (pd == null) return;
        pd.gliding = e.isGliding();
        run("ElytraA", pd, () -> Checks.ElytraA.check(pd, p, e.isGliding()));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        pd.registerRespawn();
        run("AutoRespawnA", pd, () -> Checks.AutoRespawnA.check(pd));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        // anything the server itself did is not the client moving
        if (e.getCause() != PlayerTeleportEvent.TeleportCause.PLUGIN) return;
        pd.teleportReset(e.getTo());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onVelocity(PlayerVelocityEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        // server side knockback and plugin launches are legit velocity
        pd.serverVelocity = e.getVelocity();
        pd.serverVelocityTicks = 10;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onVehicleEnter(VehicleEnterEvent e) {
        if (!(e.getEntered() instanceof Player p)) return;
        PlayerData pd = data(p);
        if (pd != null) pd.teleportReset(p.getLocation());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSneak(PlayerToggleSneakEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd != null) pd.sneaking = e.isSneaking();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSprint(PlayerToggleSprintEvent e) {
        PlayerData pd = data(e.getPlayer());
        if (pd == null) return;
        pd.sprinting = e.isSprinting();
        run("SprintA", pd, () -> Checks.SprintA.check(pd, e.getPlayer()));
        run("BadPacketsA", pd, () -> Checks.BadPacketsA.check(pd));
    }

    private PlayerData data(Player p) {
        if (exempt.contains(p.getUniqueId())) return null;
        if (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return null;
        if (p.hasPermission("acore.bypass")) return null;
        return players.get(p.getUniqueId());
    }

    // ==================================================================
    // check runner and punishment
    // ==================================================================

    interface CheckFn { boolean run(); }

    private void run(String name, PlayerData pd, CheckFn fn) {
        if (!enabled(name)) return;
        boolean failed;
        try {
            failed = fn.run();
        } catch (Exception ex) {
            // a check should never be able to take the server down
            getLogger().warning("check " + name + " threw " + ex);
            return;
        }
        if (failed) flag(pd, name, 1);
        else reward(pd, name);
    }

    void flag(PlayerData pd, String check, int amount) {
        CheckConfig cc = checks.get(check);
        int max = cc == null ? 20 : cc.maxVl;
        pd.violations.merge(check, (double) amount, Double::sum);
        pd.totalFlags += amount;
        if (debug) getLogger().info(pd.name + " flagged " + check + " vl=" + pd.violations.get(check));

        double vl = pd.violations.get(check);
        if (vl >= 5 && vl - amount < 5 && alertsEnabled) {
            alert(pd, check, vl);
        }
        if (max > 0 && vl >= VL_SETBACK(max)) setback(pd, check);
        if (max > 0 && vl >= max) ban(pd, check);
    }

    /** setback threshold sits at half the ban threshold, min 5 */
    private static int VL_SETBACK(int maxVl) {
        return Math.max(5, maxVl / 2);
    }

    private void reward(PlayerData pd, String check) {
        Double vl = pd.violations.get(check);
        if (vl != null && vl > 0) {
            pd.violations.put(check, Math.max(0, vl - 0.25));
        }
    }

    private void alert(PlayerData pd, String check, double vl) {
        String msg = "§8[§bACore§8] §f" + pd.name + " §7failed §b" + check
                + " §7vl §f" + String.format(Locale.ROOT, "%.1f", vl)
                + " §7ping §f" + pd.ping + "ms";
        for (Player admin : Bukkit.getOnlinePlayers()) {
            if (admin.hasPermission("acore.alerts")) admin.sendMessage(msg);
        }
        getLogger().info("[alert] " + pd.name + " " + check + " vl=" + vl);
        logFlag("ALERT " + pd.name + " " + check + " vl=" + String.format(Locale.ROOT, "%.1f", vl)
                + " ping=" + pd.ping + " flags=" + pd.totalFlags);
    }

    private void setback(PlayerData pd, String check) {
        Player p = Bukkit.getPlayer(pd.id);
        if (p == null || pd.lastSafe == null) return;
        // run on the main thread, move events always are but be safe anyway
        Bukkit.getScheduler().runTask(this, () -> {
            Player online = p.isOnline() ? p : null;
            if (online != null) {
                online.teleport(pd.lastSafe);
                online.sendMessage("§8[§bACore§8] §7lag back (" + check + ")");
            }
        });
        pd.violations.put(check, Math.max(0, pd.violations.get(check) - 5));
    }

    private void ban(PlayerData pd, String check) {
        Player p = Bukkit.getPlayer(pd.id);
        if (p == null || p.isBanned()) return;

        String banId = newBanId();
        String reason = "Unfair advantage (" + check + ")";
        int flags = pd.totalFlags;

        if (debug) getLogger().info("banning " + pd.name + " for " + check + " flags=" + flags);

        Bukkit.getBanList(BanList.Type.NAME).addBan(
                p.getName(), banScreen(banId, reason), new Date(System.currentTimeMillis() + BAN_MS), "ACore");

        String kickMessage = banScreen(banId, reason);
        Bukkit.getScheduler().runTask(this, () -> {
            Player online = Bukkit.getPlayer(pd.id);
            if (online != null) online.kickPlayer(kickMessage);
        });

        Bukkit.getScheduler().runTaskAsynchronously(this, () -> sendWebhook(pd.name, banId, reason, flags));
    }

    private void hourlySummary() {
        int flagged = 0, bans = 0;
        for (PlayerData pd : players.values()) {
            if (pd.totalFlags > 0) flagged++;
        }
        for (Player admin : Bukkit.getOnlinePlayers()) {
            if (admin.hasPermission("acore.alerts")) {
                admin.sendMessage("§8[§bACore§8] §7hourly: §f" + players.size() + " §7online, §f"
                        + flagged + " §7with flags");
            }
        }
        logFlag("SUMMARY online=" + players.size() + " flagged=" + flagged);
    }

    private static String newBanId() {
        StringBuilder sb = new StringBuilder(9);
        for (int i = 0; i < 9; i++) {
            if (i == 4) sb.append('-');
            sb.append(BAN_CHARS.charAt(RANDOM.nextInt(BAN_CHARS.length())));
        }
        return sb.toString();
    }

    private static String banScreen(String banId, String reason) {
        String line = "§8§m                                        ";
        return line + "\n\n"
                + "§c§lBanned by the anticheat\n\n"
                + "§7Time: §f14d\n"
                + "§7Ban ID: §f" + banId + "\n"
                + "§7Reason: §f" + reason + "\n\n"
                + "§7Msg from the developer:\n"
                + "§fWe make a mistake? Appeal your ban\n"
                + "§fon our discord server\n"
                + "§b" + APPEAL_URL + "\n\n"
                + line;
    }

    private static void sendWebhook(String user, String banId, String reason, int flags) {
        if (instance == null || instance.webhookUrl == null || instance.webhookUrl.isEmpty()) return;
        String skin = "https://minotar.net/helm/" + user + "/128.png";
        String json = "{\"username\":\"ACore Anticheat\",\"embeds\":[{"
                + "\"title\":\"\\uD83D\\uDD28 Player Ban\","
                + "\"color\":15158332,"
                + "\"thumbnail\":{\"url\":\"" + skin + "\"},"
                + "\"author\":{\"name\":\"" + user + "\",\"icon_url\":\"" + skin + "\"},"
                + "\"fields\":["
                + "{\"name\":\"User\",\"value\":\"" + user + "\",\"inline\":true},"
                + "{\"name\":\"Time\",\"value\":\"14d\",\"inline\":true},"
                + "{\"name\":\"Ban ID\",\"value\":\"`" + banId + "`\",\"inline\":false},"
                + "{\"name\":\"Reason\",\"value\":\"" + reason + "\",\"inline\":false},"
                + "{\"name\":\"Flags before ban\",\"value\":\"" + flags + "\",\"inline\":true}"
                + "],"
                + "\"footer\":{\"text\":\"ACore Anticheat \\u2022 appeal on our discord server\"}"
                + "}]}";
        try {
            HttpURLConnection conn = (HttpURLConnection) URI.create(instance.webhookUrl).toURL().openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            try (OutputStream out = conn.getOutputStream()) {
                out.write(json.getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            if (code >= 300) {
                instance.getLogger().warning("webhook returned " + code);
            }
        } catch (Exception ex) {
            // never let a webhook outage touch the server
            if (instance != null) instance.getLogger().warning("webhook failed: " + ex.getMessage());
        }
    }

    // ==================================================================
    // per player state
    // ==================================================================

    static final class Move {
        final double dx, dy, dz, hDist;
        final Location from, to;
        Move(Location from, Location to) {
            this.from = from;
            this.to = to;
            this.dx = to.getX() - from.getX();
            this.dy = to.getY() - from.getY();
            this.dz = to.getZ() - from.getZ();
            this.hDist = Math.hypot(dx, dz);
        }
    }

    /** all per player state in one place, keyed by uuid, cleared on quit */
    static final class PlayerData {
        final UUID id;
        String name;
        int ping;

        // movement
        Location lastSafe;
        long lastMoveMs;
        double lastDy;
        int airTicks, groundTicks, liquidTicks, climbTicks, consecutiveFast;
        boolean onGround, nearGround, inLiquid, onLadder, gliding, sneaking, sprinting, moving;
        double serverVelocityTicks;
        Vector serverVelocity;

        // rolling one second window for velocity style checks (VelocityA idea)
        final Deque<long[]> positions = new ArrayDeque<>(); // {millis, x100, y100, z100}
        double windowDy, windowDh;

        // combat
        float lastYaw, lastPitch;
        boolean hadRotation;
        double yawDeltaSum, yawSnapCount;
        final Deque<Long> attacks = new ArrayDeque<>();
        final Deque<Long> swings = new ArrayDeque<>();
        final Deque<Long> clicks = new ArrayDeque<>();
        final Deque<Double> clickGaps = new ArrayDeque<>();
        final Deque<Double> hitDistances = new ArrayDeque<>();
        long lastAttackTickYawSample;
        float yawAtLastAttack;

        // world
        final Deque<Long> breaks = new ArrayDeque<>();
        final Deque<Long> places = new ArrayDeque<>();
        final Deque<Long> consumes = new ArrayDeque<>();
        final Deque<Long> chat = new ArrayDeque<>();
        final Deque<Long> invClicks = new ArrayDeque<>();
        final Deque<Long> respawns = new ArrayDeque<>();
        final Deque<Long> offhandSwaps = new ArrayDeque<>();
        final Deque<Long> keepalives = new ArrayDeque<>();
        final Deque<Location> breakLocs = new ArrayDeque<>();
        int bowTicks;
        long lastPlaceMs;
        long lastBlockDamageMs;
        int hotbarSlot;
        long slotChangeMs;
        long lastBreakMs;

        boolean xrayAlerted;
        final Deque<Long> timerBursts = new ArrayDeque<>();
        final Deque<Long> flatCrits = new ArrayDeque<>();

        // xray heuristics
        int deepslateDiamonds;
        final Deque<Long> diamondTimes = new ArrayDeque<>();

        // misc
        final Map<String, Double> violations = new HashMap<>();
        int totalFlags;
        double vlDecayAccumulator;

        PlayerData(Player p) {
            this.id = p.getUniqueId();
            this.name = p.getName();
            this.lastSafe = p.getLocation();
        }

        void rebuild(Player p) {
            name = p.getName();
            ping = p.getPing();
            onGround = p.isOnGround();
            inLiquid = p.getLocation().getBlock().isLiquid()
                    || p.getEyeLocation().getBlock().isLiquid();
            onLadder = isClimbable(p.getLocation().getBlock())
                    || isClimbable(p.getEyeLocation().getBlock());
            nearGround = onGround || groundBelow(p, 1) || ladderBeside(p);
            gliding = p.isGliding();
            if (serverVelocityTicks > 0) serverVelocityTicks--;
            if (bowTicks > 0) bowTicks--;
        }

        void moveTick(Player p, Move m) {
            long now = System.currentTimeMillis();
            long delta = now - lastMoveMs;
            lastMoveMs = now;
            moving = true;

            if (m.dy > 0.0001) {
                airTicks++;
                groundTicks = 0;
            } else if (m.dy < -0.0001) {
                airTicks++;
                groundTicks = 0;
            } else if (onGround) {
                groundTicks++;
                airTicks = 0;
            }

            liquidTicks = inLiquid ? liquidTicks + 1 : 0;
            climbTicks = onLadder ? climbTicks + 1 : 0;

            // one second rolling window, used by VelocityA
            positions.addLast(new long[]{now,
                    (long) (m.to.getX() * 100), (long) (m.to.getY() * 100), (long) (m.to.getZ() * 100)});
            windowDy += m.dy;
            windowDh += m.hDist;
            while (positions.size() > 1 && now - positions.peekFirst()[0] > 1000) {
                positions.removeFirst();
            }

            if (onGround && !m.from.getBlock().isLiquid() && !isClimbable(m.from.getBlock())) {
                lastSafe = m.from.clone();
            }
        }

        void rotationTick(Player p, float yaw, float pitch) {
            if (hadRotation) {
                float dyaw = Math.abs(yaw - lastYaw);
                if (dyaw > 180) dyaw = 360 - dyaw;
                yawDeltaSum = yawDeltaSum * 0.8 + dyaw * 0.2;
                if (dyaw > 30) yawSnapCount++;
                else if (yawSnapCount > 0) yawSnapCount -= 0.25;
            }
            lastYaw = yaw;
            lastPitch = pitch;
            hadRotation = true;
        }

        void teleportReset(Location to) {
            lastSafe = to.clone();
            airTicks = 0;
            lastDy = 0;
            positions.clear();
            windowDy = 0;
            windowDh = 0;
            serverVelocityTicks = 0;
        }

        void registerClick() { clicks.addLast(System.currentTimeMillis()); trim(clicks); }
        void registerSwing() { swings.addLast(System.currentTimeMillis()); trim(swings); }
        void registerAttack() { attacks.addLast(System.currentTimeMillis()); trim(attacks); }
        void registerConsume() { consumes.addLast(System.currentTimeMillis()); trim(consumes); }
        void registerChat() { chat.addLast(System.currentTimeMillis()); trim(chat); }
        void registerInvClick() { invClicks.addLast(System.currentTimeMillis()); trim(invClicks); }
        void registerRespawn() { respawns.addLast(System.currentTimeMillis()); trim(respawns); }
        void registerOffhandSwap() { offhandSwaps.addLast(System.currentTimeMillis()); trim(offhandSwaps); }

        void registerBreak(Material type, Location loc) {
            long now = System.currentTimeMillis();
            breaks.addLast(now);
            trim(breaks);
            breakLocs.addLast(loc);
            while (breakLocs.size() > 20) breakLocs.removeFirst();
            lastBreakMs = now;
            if (type == Material.DIAMOND_ORE || type == Material.DEEPSLATE_DIAMOND_ORE) {
                deepslateDiamonds++;
                diamondTimes.addLast(now);
                while (diamondTimes.size() > 30) diamondTimes.removeFirst();
            }
        }

        void registerPlaceSelf(Location self) {
            long now = System.currentTimeMillis();
            places.addLast(now);
            trim(places);
            lastPlaceMs = now;
        }

        void registerPlace(Location against, Location self) { lastPlaceMs = System.currentTimeMillis(); }

        void blockDamageTick(Player p) {
            lastBlockDamageMs = System.currentTimeMillis();
        }

        /** keepalive style timing samples, used by the ping spoof heuristic */
        void keepAliveSample() {
            keepalives.addLast(System.currentTimeMillis());
            trim(keepalives);
        }

        private static void trim(Deque<Long> q) {
            long cutoff = System.currentTimeMillis() - 5000;
            while (!q.isEmpty() && q.peekFirst() < cutoff) q.removeFirst();
        }

        int countLast(Deque<Long> q, long windowMs) {
            long cutoff = System.currentTimeMillis() - windowMs;
            int n = 0;
            for (long t : q) if (t >= cutoff) n++;
            return n;
        }

        private static boolean isClimbable(Block b) {
            Material t = b.getType();
            return t == Material.LADDER || t == Material.VINE
                    || t == Material.SCAFFOLDING || t.name().endsWith("_TRAPDOOR") && b.isPassable();
        }

        private static boolean groundBelow(Player p, int depth) {
            Location l = p.getLocation();
            for (int i = 1; i <= depth; i++) {
                Block b = l.clone().subtract(0, i, 0).getBlock();
                if (!b.isPassable()) return true;
            }
            return false;
        }

        private static boolean ladderBeside(Player p) {
            Location l = p.getLocation();
            BlockFace[] sides = {BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};
            for (BlockFace f : sides) {
                if (isClimbable(l.getBlock().getRelative(f))) return true;
            }
            return false;
        }
    }

    // ==================================================================
    // the checks
    //
    // every check returns true when it wants to flag. they see the player
    // through PlayerData only, so they stay small and testable.
    // ==================================================================

    static final class Checks {

        // ---------------- movement ----------------

        /**
         * SpeedA: horizontal speed above vanilla with tolerance for latency,
         * speed effects and ice. needs two consecutive fast ticks so a single
         * rubber band or client desync does not flag.
         */
        static boolean SpeedA(PlayerData pd, Move m) {
            double limit = 0.44;
            if (pd.sprinting) limit += 0.06;
            double speed = potionLevel(playerOf(pd), PotionEffectType.SPEED);
            if (speed > 0) limit *= 1 + speed * 0.4;
            if (pd.inLiquid) limit += 0.1;
            if (pd.gliding) return false;
            if (pd.serverVelocityTicks > 0) return false;
            if (pd.ping > 200) limit += 0.2;

            boolean fast = m.hDist > limit;
            // two fast ticks in a row before we speak up, one can be lag
            if (fast && pd.airTicks > 0 && pd.airTicks < 3) return false;
            if (fast) {
                if (pd.consecutiveFast < 1) {
                    pd.consecutiveFast++;
                    return false;
                }
                return true;
            }
            pd.consecutiveFast = 0;
            return false;
        }

        /**
         * SpeedB: air speed without sprint. vanilla air control is tiny, if
         * someone covers distance mid air while not sprinting that is a cheat.
         */
        static boolean SpeedB(PlayerData pd, Move m) {
            if (pd.sprinting || pd.onGround || pd.gliding) return false;
            if (pd.serverVelocityTicks > 0) return false;
            if (pd.airTicks > 4 && pd.airTicks < 40 && m.hDist > 0.35) return true;
            return false;
        }

        /**
         * VelocityA: how many blocks per second the player gained vertically
         * and horizontally over the last second of movement. vanilla tops out
         * around 3.5 up and 6 across, we flag past 1.6x of that. elytra,
         * levitation and riptide are all exempt or this would ban legit gliders.
         */
        static boolean VelocityA(PlayerData pd, Player p) {
            if (pd.gliding) return false;
            if (p.getInventory().getChestplate() != null
                    && p.getInventory().getChestplate().getType() == Material.ELYTRA) return false;
            if (p.hasPotionEffect(PotionEffectType.LEVITATION)) return false;
            if (p.getInventory().getItemInMainHand().getType() == Material.TRIDENT) return false;
            if (pd.serverVelocityTicks > 0) return false;
            if (pd.positions.size() < 4) return false;
            if (pd.nearGround && pd.windowDy >= 0) return false;

            double dyPerSec = pd.windowDy;
            double dhPerSec = pd.windowDh;
            if (dyPerSec > 3.5 * 1.6) return true;
            if (dhPerSec > 6.0 * 1.6 && !pd.inLiquid) return true;
            return false;
        }

        /** StepA: vanilla steps up at most 0.6 on a slab, 1.0 with jump. more is a step cheat. */
        static boolean StepA(PlayerData pd, Move m) {
            if (pd.gliding || pd.inLiquid || pd.onLadder) return false;
            if (pd.serverVelocityTicks > 0) return false;
            double limit = 1.05;
            if (m.dy > limit) return true;
            return false;
        }

        /**
         * FlyA: hover detection. after 25 ticks in the air the player must be
         * meaningfully below where they started, otherwise they are fighting
         * gravity somehow. slow falling and levitation exempt.
         */
        static boolean FlyA(PlayerData pd, Move m) {
            Player p = playerOf(pd);
            if (p == null) return false;
            if (p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) return false;
            if (p.hasPotionEffect(PotionEffectType.LEVITATION)) return false;
            if (p.hasPotionEffect(PotionEffectType.JUMP_BOOST)) return false;
            if (p.isFlying() || p.getAllowFlight()) return false;
            if (pd.gliding || pd.inLiquid || pd.onLadder || pd.serverVelocityTicks > 0) return false;

            if (pd.airTicks == 25 && m.dy > -0.02 && !pd.nearGround) return true;
            if (pd.airTicks > 40 && m.dy > 0.05) return true;
            return false;
        }

        /** JesusA: horizontal movement while fully inside a liquid, without frost walker. */
        static boolean JesusA(PlayerData pd, Move m) {
            Player p = playerOf(pd);
            if (p == null) return false;
            if (p.isInsideVehicle()) return false;
            if (p.getInventory().getBoots() != null
                    && p.getInventory().getBoots().getEnchantmentLevel(Enchantment.FROST_WALKER) > 0) return false;
            if (pd.liquidTicks > 4 && m.hDist > 0.32 && m.dy >= -0.01) return true;
            return false;
        }

        /** SneakA: sneak movement cap is about 0.13 per tick, plus depth strider in water. */
        static boolean SneakA(PlayerData pd, Move m) {
            if (!pd.sneaking || pd.gliding) return false;
            if (m.hDist > 0.16 && pd.liquidTicks == 0) return true;
            return false;
        }

        /** SprintA: you cannot sprint while blind or floating in a vehicle. */
        static boolean SprintA(PlayerData pd, Player p) {
            if (!pd.sprinting) return false;
            if (p.hasPotionEffect(PotionEffectType.BLINDNESS)) return true;
            if (p.getFoodLevel() <= 6) return true;
            return false;
        }

        /** SpiderA: vertical climb on a plain wall. vanilla cannot do this without a ladder. */
        static boolean SpiderA(PlayerData pd, Move m) {
            if (pd.onLadder || pd.inLiquid || pd.gliding) return false;
            if (m.dy <= 0.02 || m.dy > 0.2) return false;
            Player p = playerOf(pd);
            if (p == null) return false;
            Location l = p.getLocation();
            BlockFace[] sides = {BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};
            boolean touchingWall = false;
            for (BlockFace f : sides) {
                Block b = l.getBlock().getRelative(f);
                if (!b.isPassable()) { touchingWall = true; break; }
                Block above = l.clone().add(0, 1, 0).getBlock().getRelative(f);
                if (!above.isPassable()) { touchingWall = true; break; }
            }
            if (!touchingWall) return false;
            if (p.hasPotionEffect(PotionEffectType.LEVITATION)) return false;
            return true;
        }

        /** HighJumpA: vanilla jump is 1.25 plus 0.3 per jump boost level. more is modified. */
        static boolean HighJumpA(PlayerData pd, Move m) {
            Player p = playerOf(pd);
            if (p == null) return false;
            if (pd.airTicks != 1 || m.dy <= 1.3) return false;
            if (pd.serverVelocityTicks > 0) return false;
            PotionEffect jb = p.getPotionEffect(PotionEffectType.JUMP_BOOST);
            double limit = 1.35 + (jb == null ? 0 : jb.getAmplifier() * 0.35);
            if (m.dy > limit) return true;
            return false;
        }

        /** LevitateA: rising steadily without any vanilla reason to rise. */
        static boolean LevitateA(PlayerData pd, Move m) {
            Player p = playerOf(pd);
            if (p == null) return false;
            if (p.hasPotionEffect(PotionEffectType.LEVITATION)) return false;
            if (p.hasPotionEffect(PotionEffectType.JUMP_BOOST)) return false;
            if (pd.gliding || pd.onLadder || pd.inLiquid || pd.serverVelocityTicks > 0) return false;
            if (pd.airTicks > 6 && pd.airTicks < 60 && m.dy > 0.09) return true;
            return false;
        }

        /** FastLadderA: vanilla climbs at 0.12 per tick without a speed potion on it. */
        static boolean FastLadderA(PlayerData pd, Move m) {
            if (!pd.onLadder) return false;
            Player p = playerOf(pd);
            if (p != null && p.hasPotionEffect(PotionEffectType.SPEED)) return false;
            if (m.dy > 0.14) return true;
            return false;
        }

        /** ElytraA: the client says gliding but there is no elytra on the chest. */
        static boolean ElytraA(PlayerData pd, Player p, boolean nowGliding) {
            if (!nowGliding) return false;
            var chest = p.getInventory().getChestplate();
            if (chest != null && chest.getType() == Material.ELYTRA) return false;
            return true;
        }

        /**
         * NoSlowA: eating, drinking and drawing a bow all apply a use slow.
         * if the player still covers near sprint distance during use, that is
         * the classic noslow module.
         */
        static boolean NoSlowA(PlayerData pd, Move m) {
            if (pd.gliding) return false;
            if (m.hDist > 0.24 && m.hDist < 0.55 && (pd.bowTicks > 0 || pd.consumes.size() > 0
                    && System.currentTimeMillis() - pd.consumes.peekLast() < 1500)) return true;
            return false;
        }

        static boolean consume(PlayerData pd) { return false; }

        // ---------------- combat ----------------

        /**
         * KillAuraA: rotation snap. legit aiming drifts smoothly, aura bots
         * snap their whole view onto the target between two packets. we track
         * an exponential moving average of yaw change and count big snaps.
         */
        static boolean KillAuraA(PlayerData pd) {
            if (pd.attacks.isEmpty()) return false;
            long lastAttack = pd.attacks.peekLast();
            // only care about snaps that happen within 100ms of an attack
            boolean nearAttack = System.currentTimeMillis() - lastAttack < 100;
            if (!nearAttack) return false;
            return pd.yawSnapCount >= 3;
        }

        /** KillAuraB: vanilla attacks are throttled by the attack cooldown, aura ignores it. */
        static boolean KillAuraB(PlayerData pd) {
            int perSec = pd.countLast(pd.attacks, 1000);
            // 12 cps of pure attacks with no misses at all is not human
            return perSec > 12;
        }

        /** KillAuraC: hits landing from directions the player was never looking at. */
        static boolean KillAuraC(PlayerData pd, Player p, Entity target) {
            org.bukkit.util.Vector look = p.getLocation().getDirection();
            org.bukkit.util.Vector toTarget = target.getLocation().toVector()
                    .subtract(p.getLocation().toVector());
            double angle = Math.toDegrees(look.angle(toTarget));
            if (angle > 75) return true;
            return false;
        }

        /** ReachA: survival reach tops out at 3.0, creative 5. 3.4 leaves creative room. */
        static boolean ReachA(PlayerData pd, double dist) {
            pd.hitDistances.addLast(dist);
            while (pd.hitDistances.size() > 30) pd.hitDistances.removeFirst();
            // single long hit can be a horse or a tall entity, need a pattern
            if (pd.hitDistances.size() < 10) return false;
            int over = 0;
            for (double d : pd.hitDistances) if (d > 3.4) over++;
            return over >= 8;
        }

        /**
         * AutoClickerA: two signals. raw cps over 20, and click gap variance
         * near zero which is what macros look like and humans never produce.
         */
        static boolean AutoClickerA(PlayerData pd) {
            int cps = pd.countLast(pd.clicks, 1000);
            if (cps > 20) return true;
            if (pd.clickGaps.size() >= 10) {
                double mean = 0;
                for (double g : pd.clickGaps) mean += g;
                mean /= pd.clickGaps.size();
                double variance = 0;
                for (double g : pd.clickGaps) variance += (g - mean) * (g - mean);
                variance /= pd.clickGaps.size();
                if (mean < 50 && variance < 2.0) return true;
            }
            return false;
        }

        /** NoHitDelayA: arm swing rate cap. vanilla can not swing faster than about 13 a second. */
        static boolean NoHitDelayA(PlayerData pd) {
            return pd.countLast(pd.swings, 1000) > 13;
        }

        /** CriticalsA: crits only happen while falling, attacking from flat ground with crit particles is a module. */
        static boolean CriticalsA(PlayerData pd, Player p, EntityDamageEvent.DamageCause cause) {
            if (cause != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return false;
            if (!pd.onGround && pd.airTicks < 3) return false;
            // attacking while ascending from a jump is legit crits, only flag flat ground crits
            if (pd.onGround && p.getFallDistance() == 0 && pd.airTicks == 0) {
                if (p.getActivePotionEffects().stream().noneMatch(e -> e.getType() == PotionEffectType.JUMP_BOOST)) {
                    pd.flatCrits.addLast(System.currentTimeMillis());
                    trimQ(pd.flatCrits);
                    return true;
                }
            }
            return false;
        }

        /**
         * HitSelectA: hit selection cancels your own damage frames so you trade
         * 1 for 0. we look for a repeating pattern of being hit then attacking
         * with almost no gap, over and over.
         */
        static boolean HitSelectA(PlayerData pd, Entity target) {
            // event level damage data is thin here, we approximate with attack rhythm:
            // hit selection shows up as attacks perfectly synced to taking damage.
            // full detection needs packets, this catches the sloppy versions.
            long now = System.currentTimeMillis();
            if (pd.attacks.size() < 6) return false;
            Long prev = null;
            int synced = 0;
            for (long t : pd.attacks) {
                if (prev != null && t - prev < 100) synced++;
                prev = t;
            }
            return synced >= 4 && now - pd.attacks.peekLast() < 200;
        }

        /** FastBowA: the draw takes 20 ticks, under 10 means the client is faking the release. */
        static boolean FastBowA(PlayerData pd) {
            return pd.bowTicks > 0 && pd.bowTicks < 10 && pd.countLast(pd.clicks, 500) > 3;
        }

        // ---------------- world ----------------

        /**
         * FastBreakA: we cannot read block break progress from events, so we
         * compare the time between two breaks of the same block type against
         * a rough tool based minimum. instant mine modules break this easily.
         */
        static boolean FastBreakA(PlayerData pd, Player p, Block b) {
            long now = System.currentTimeMillis();
            if (pd.lastBreakMs == 0) return false;
            long gap = now - pd.lastBreakMs;
            if (gap < 45) {
                // 45ms between breaks with a real tool is impossible even on
                // instant break blocks, vanilla sends one break per tick
                return true;
            }
            return false;
        }

        /** FastPlaceA: vanilla has a 4 tick cooldown between placements, under 180ms is a fastplace. */
        static boolean FastPlaceA(PlayerData pd) {
            long now = System.currentTimeMillis();
            if (now - pd.lastPlaceMs < 180 && pd.countLast(pd.places, 1000) > 7) return true;
            return false;
        }

        /** NukerA: many breaks per second spread across a wide area is a nuker, not a hyperion. */
        static boolean NukerA(PlayerData pd) {
            int perSec = pd.countLast(pd.breaks, 1000);
            if (perSec < 8) return false;
            // check the spread, mining 8 gravel in one spot can be a shovel
            if (pd.breakLocs.size() < 8) return false;
            double spread = 0;
            Location first = pd.breakLocs.peekFirst();
            for (Location l : pd.breakLocs) spread += first.distance(l);
            return spread / pd.breakLocs.size() > 4;
        }

        /**
         * GhostHandA: the block they broke has no clear line from the eyes.
         * legit players physically cannot break what they cannot see.
         */
        static boolean GhostHandA(PlayerData pd, Player p, Block b) {
            try {
                org.bukkit.util.Vector eye = p.getEyeLocation().toVector();
                org.bukkit.util.Vector block = b.getLocation().toVector().add(new org.bukkit.util.Vector(0.5, 0.5, 0.5));
                if (eye.distance(block) > 6) return false;
                // walk the ray and if a solid block sits in front of the target the hit is impossible
                org.bukkit.util.Vector dir = block.clone().subtract(eye).normalize();
                for (double t = 0.5; t < eye.distance(block) - 0.5; t += 0.5) {
                    Block step = eye.clone().add(dir.clone().multiply(t)).toLocation(p.getWorld()).getBlock();
                    if (!step.isPassable() && !step.equals(b)) return true;
                }
            } catch (IllegalArgumentException ignored) {
                // zero length direction, eye inside the block, harmless
            }
            return false;
        }

        /** AutoToolA: hotbar slot flips to the exact tool the same tick a block damage starts. */
        static boolean AutoToolA(PlayerData pd) {
            long now = System.currentTimeMillis();
            if (pd.slotChangeMs == 0) return false;
            return now - pd.slotChangeMs < 20 && now - pd.lastBlockDamageMs < 50;
        }

        /** ScaffoldA: sprint bridging without looking at the block below is a scaffold module. */
        static boolean ScaffoldA(PlayerData pd, Player p, Move m) {
            if (pd.onGround) return false;
            int places = pd.countLast(pd.places, 900);
            if (places < 5) return false;
            // placing blocks behind you while sprinting forward with your camera
            // held up: vanilla players look down to bridge
            float pitch = Math.abs(pd.lastPitch);
            if (pitch < 35 && pd.sprinting && m.hDist > 0.25) return true;
            return false;
        }

        static boolean interact(PlayerData pd, Player p) {
            // bridge fly places blocks while falling diagonally, no legit way
            if (!pd.onGround && pd.airTicks > 12 && pd.countLast(pd.places, 900) >= 5) return true;
            return false;
        }

        /** LiquidInteractA: placing against water you are not looking at. needs ray data for full accuracy. */
        static boolean LiquidInteractA(PlayerData pd, Player p) {
            return false; // needs the clicked block face, added when we wire the packet layer
        }

        /**
         * XrayA: never bans by itself. counts diamonds per minute while deep
         * underground and alerts staff for manual review, because event data
         * cannot prove xray, only that the mining pattern is not human.
         */
        static boolean XrayA(PlayerData pd, Player p, Block b) {
            if (b.getY() > -10) return false;
            if (pd.diamondTimes.size() < 15) return false;
            long span = pd.diamondTimes.peekLast() - pd.diamondTimes.peekFirst();
            // 15 diamonds in under 3 minutes while deep means staff should look
            if (span < 180_000) {
                if (!pd.xrayAlerted) {
                    pd.xrayAlerted = true;
                    for (Player admin : Bukkit.getOnlinePlayers()) {
                        if (admin.hasPermission("acore.alerts")) {
                            admin.sendMessage("§8[§bACore§8] §e" + pd.name + " mining pattern looks xray, review manually");
                        }
                    }
                }
            }
            return false;
        }

        /**
         * TimerA: event rate above the server tick rate. if the player produces
         * 25 percent more move events than the server runs ticks, their client
         * is speeding up its own clock.
         */
        static boolean TimerA(PlayerData pd) {
            int moves = pd.countLast(positions(pd), 1000);
            return moves > 25;
        }

        private static Deque<long[]> positions(PlayerData pd) { return pd.positions; }

        /** FastEatA: eating takes 32 ticks, under 1.2s between consumes is fake. */
        static boolean FastEatA(PlayerData pd) {
            if (pd.consumes.size() < 2) return false;
            Long prev = null;
            for (long t : pd.consumes) {
                if (prev != null && t - prev < 1200) return true;
                prev = t;
            }
            return false;
        }

        /** InventoryMoveA: clicking your inventory while covering sprint distance. */
        static boolean InventoryMoveA(PlayerData pd, Move m) {
            if (m.hDist < 0.28) return false;
            long lastClick = pd.invClicks.isEmpty() ? 0 : pd.invClicks.peekLast();
            return System.currentTimeMillis() - lastClick < 200;
        }

        /** FastChestA: inventory clicks per second above even the fastest jitter clickers. */
        static boolean FastChestA(PlayerData pd) {
            return pd.countLast(pd.invClicks, 1000) > 25;
        }

        /** NoRotationA: breaking or placing with a camera that never moved for two seconds. */
        static boolean NoRotationA(PlayerData pd) {
            if (pd.breaks.isEmpty() && pd.places.isEmpty()) return false;
            return pd.yawDeltaSum < 0.001 && pd.countLast(pd.breaks, 2000) > 2;
        }

        // ---------------- misc ----------------

        /** ChatSpamA: 6 messages in 5 seconds is beyond any legit conversation. */
        static boolean ChatSpamA(PlayerData pd) {
            return pd.countLast(pd.chat, 5000) >= 6;
        }

        /** AutoRespawnA: instant respawn on a fixed rhythm is a macro. */
        static boolean AutoRespawnA(PlayerData pd) {
            return pd.countLast(pd.respawns, 15000) >= 5;
        }

        /**
         * PingSpoofA: keepalive gap variance pinned near zero. real networks
         * jitter, spoofers send keepalives on a fixed schedule to hide lag.
         */
        static boolean PingSpoofA(PlayerData pd) {
            if (pd.keepalives.size() < 10) return false;
            Long prev = null;
            double sum = 0, sumSq = 0;
            int n = 0;
            for (long t : pd.keepalives) {
                if (prev != null) {
                    double gap = t - prev;
                    sum += gap;
                    sumSq += gap * gap;
                    n++;
                }
                prev = t;
            }
            double mean = sum / n;
            double var = sumSq / n - mean * mean;
            return mean > 0 && var < 1.0;
        }

        /** BadPacketsA: state combos the client cannot produce, like sprinting mid sneak. */
        static boolean BadPacketsA(PlayerData pd) {
            if (pd.sprinting && pd.sneaking) return true;
            return false;
        }

        private static void trimQ(Deque<Long> q) {
            long cutoff = System.currentTimeMillis() - 5000;
            while (!q.isEmpty() && q.peekFirst() < cutoff) q.removeFirst();
        }

        // ---------------- helpers ----------------

        private static double potionLevel(Player p, PotionEffectType type) {
            if (p == null) return 0;
            PotionEffect e = p.getPotionEffect(type);
            return e == null ? 0 : e.getAmplifier() + 1;
        }

        static Player playerOf(PlayerData pd) {
            return Bukkit.getPlayer(pd.id);
        }
    }

    // ==================================================================
    // second generation checks
    //
    // these use statistical windows instead of single tick thresholds.
    // they flag slower but they hold up in appeals because the numbers
    // are not a one off, they are a pattern.
    // ==================================================================

    static final class Checks2 {

        /** SpeedC: average horizontal speed over one second, catches smooth speed cheats. */
        static boolean SpeedC(PlayerData pd, Move m) {
            if (pd.gliding || pd.serverVelocityTicks > 0) return false;
            // sprint on flat ground averages 5.6 blocks a second, 8+ is modified
            return pd.windowDh > 8.0 && pd.positions.size() > 8;
        }

        /** FlyB: vertical drop profile. real gravity accelerates, cheats fall flat or hover. */
        static boolean FlyB(PlayerData pd, Move m) {
            if (pd.onGround || pd.gliding || pd.inLiquid || pd.onLadder) return false;
            if (m.dy >= -0.05 || m.dy <= -0.9) return false;
            // after 15 ticks in the air, vanilla dy grows by about 0.08 per tick
            if (pd.airTicks > 15 && Math.abs(m.dy - pd.lastDy) < 0.005) return true;
            return false;
        }

        /** VelocityB: knockback taken. if the server pushes and the player does not move, they cancel kb. */
        static boolean VelocityB(PlayerData pd, Move m) {
            if (pd.serverVelocityTicks <= 0 || pd.serverVelocity == null) return false;
            double pushed = Math.abs(pd.serverVelocity.getX()) + Math.abs(pd.serverVelocity.getZ());
            if (pushed < 0.2) return false;
            double taken = Math.abs(m.dx) + Math.abs(m.dz);
            // took less than a third of the knockback for several ticks
            return taken < pushed / 3 && pd.serverVelocityTicks > 6;
        }

        /** TimerB: balance of move events against wall clock, the smooth version of TimerA. */
        static boolean TimerB(PlayerData pd) {
            int moves = pd.countLast(pd.positions, 4000);
            // 20 ticks a second means 80 moves in 4 seconds, 100 is 25 percent fast
            return moves > 100;
        }

        /** AimAssistA: rotation entropy. aim assist produces inhumanly uniform small yaw deltas. */
        static boolean AimAssistA(PlayerData pd) {
            if (pd.attacks.isEmpty()) return false;
            if (pd.yawDeltaSum <= 0) return false;
            // legit aiming alternates big and small corrections, assist does not
            return pd.yawDeltaSum > 0.5 && pd.yawDeltaSum < 1.2 && pd.yawSnapCount == 0
                    && pd.countLast(pd.attacks, 2000) >= 8;
        }

        /** KillAuraD: one attacker hitting several entities inside a single second. */
        static boolean KillAuraD(PlayerData pd) {
            return pd.countLast(pd.attacks, 1000) >= 6 && pd.yawSnapCount >= 2;
        }

        /** ReachB: average reach over the last 30 hits, the statistical version of ReachA. */
        static boolean ReachB(PlayerData pd) {
            if (pd.hitDistances.size() < 30) return false;
            double sum = 0;
            for (double d : pd.hitDistances) sum += d;
            return sum / pd.hitDistances.size() > 3.25;
        }

        /** MacroA: clicks at a constant rate for five straight seconds, humans breathe. */
        static boolean MacroA(PlayerData pd) {
            int a = pd.countLast(pd.clicks, 1000);
            int b = pd.countLast(pd.clicks, 5000) - a;
            // same cps in the last second as across the whole five seconds
            return a >= 10 && Math.abs(a - b / 4.0) < 0.8;
        }

        /** ScaffoldB: rotation while placing. legit bridgers rotate the camera, modules do not. */
        static boolean ScaffoldB(PlayerData pd, Move m) {
            return pd.countLast(pd.places, 1000) >= 8 && pd.yawDeltaSum < 0.01;
        }

        /**
         * AutoTotemA: in a lifesteal fight the totem in the offhand is life or
         * death, so modules swap a fresh totem in the same tick the old one
         * pops. five offhand swaps in two seconds is not a human with a mouse.
         */
        static boolean AutoTotemA(PlayerData pd) {
            int swaps = pd.countLast(pd.offhandSwaps, 2000);
            if (swaps < 5) return false;
            // only flag when it happens during combat, chest room organisation is legit
            return pd.countLast(pd.attacks, 3000) > 0;
        }

        /** NoSlowB: statistical version of NoSlowA, average speed while using an item. */
        static boolean NoSlowB(PlayerData pd, Move m) {
            if (pd.bowTicks <= 0 || pd.gliding) return false;
            // vanilla use slow caps you around 0.1 per tick, sprint noslow shows 0.3+
            return pd.windowDh > 4.5 && pd.bowTicks > 0 && pd.positions.size() > 8;
        }

        /** StepB: statistical step, three oversized vertical moves inside a second. */
        static boolean StepB(PlayerData pd, Move m) {
            if (pd.inLiquid || pd.onLadder || pd.gliding) return false;
            return m.dy > 0.9 && pd.airTicks > 0 && pd.consecutiveFast >= 0;
        }

        /** SpeedD: acceleration snap. vanilla movement eases in, cheats jump to full speed in one tick. */
        static boolean SpeedD(PlayerData pd, Move m) {
            if (pd.onGround || pd.serverVelocityTicks > 0) return false;
            // jumping from 0 to full sprint distance in one tick is not vanilla
            return m.hDist > 0.5 && pd.airTicks == 1;
        }

        /** JesusB: statistical jesus, five seconds of liquid top walking. */
        static boolean JesusB(PlayerData pd, Move m) {
            if (pd.liquidTicks < 20 || pd.gliding) return false;
            return pd.windowDh > 5.0;
        }

        /** FastBreakB: same-block instant rebreak, one block broken twice inside 200ms. */
        static boolean FastBreakB(PlayerData pd, Location loc) {
            // breakLocs holds the last 20, a repeated identical spot this fast is a nuker loop
            int seen = 0;
            for (Location l : pd.breakLocs) {
                if (l.getBlockX() == loc.getBlockX()
                        && l.getBlockY() == loc.getBlockY()
                        && l.getBlockZ() == loc.getBlockZ()) seen++;
            }
            return seen > 1 && pd.countLast(pd.breaks, 1000) > 6;
        }

        /** KillAuraE: attack rhythm perfectly regular, aura loops fire on a fixed interval. */
        static boolean KillAuraE(PlayerData pd) {
            if (pd.attacks.size() < 8) return false;
            Long prev = null;
            double sum = 0, sumSq = 0;
            int n = 0;
            for (long t : pd.attacks) {
                if (prev != null) {
                    double gap = t - prev;
                    sum += gap;
                    sumSq += gap * gap;
                    n++;
                }
                prev = t;
            }
            double mean = sum / n;
            double var = sumSq / n - mean * mean;
            // regular 500ms+ rhythm is legit pvp, regular sub 250ms is not
            return mean < 250 && var < 100;
        }

        /** TimerC: three strikes of TimerA inside five seconds. one burst is lag, three is a timer. */
        static boolean TimerC(PlayerData pd) {
            long now = System.currentTimeMillis();
            pd.timerBursts.removeIf(t -> now - t > 5000);
            if (pd.countLast(pd.positions, 1000) > 25) {
                pd.timerBursts.addLast(now);
            }
            return pd.timerBursts.size() >= 3;
        }

        /** CriticalsB: statistical crits, four flat ground crits inside two seconds. */
        static boolean CriticalsB(PlayerData pd) {
            return pd.countLast(pd.flatCrits, 2000) >= 4;
        }

        /** HitSelectB: damage window sync across a longer window, the pattern version. */
        static boolean HitSelectB(PlayerData pd) {
            if (pd.attacks.size() < 12) return false;
            Long prev = null;
            int tight = 0, total = 0;
            for (long t : pd.attacks) {
                if (prev != null) {
                    total++;
                    if (t - prev < 120) tight++;
                }
                prev = t;
            }
            return total >= 10 && tight * 2 >= total;
        }

        /** InvMoveB: statistical inventory movement, clicks while covering distance over and over. */
        static boolean InvMoveB(PlayerData pd, Move m) {
            return m.hDist > 0.25 && pd.countLast(pd.invClicks, 2000) >= 8;
        }
    }

    // ==================================================================
    // flag logging
    //
    // every flag gets a line in plugins/ACore/flags.log. when someone
    // appeals a ban you pull the file and read the whole history.
    // ==================================================================

    private final Object logLock = new Object();

    private void logFlag(String line) {
        if (!getConfig().getBoolean("log-file", true)) return;
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            synchronized (logLock) {
                try {
                    java.io.File dir = getDataFolder();
                    if (!dir.exists()) dir.mkdirs();
                    java.io.FileWriter fw = new java.io.FileWriter(
                            new java.io.File(dir, "flags.log"), true);
                    fw.write(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                            .format(new java.util.Date()) + " " + line + "\n");
                    fw.close();
                } catch (Exception ignored) {
                    // a broken log must never break a check
                }
            }
        });
    }

    // ==================================================================
    // small utils
    // ==================================================================

    private static final class Util {
        static double clamp(double v, double min, double max) {
            return Math.max(min, Math.min(max, v));
        }
    }
}
