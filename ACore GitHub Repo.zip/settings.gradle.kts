rootProject.name = "ACore"
